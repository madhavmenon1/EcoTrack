import React, { useState, useEffect } from 'react';
import { Dashboard } from './components/Dashboard';
import { Settings } from './components/Settings';
import { Header } from './components/Header';
import { Sidebar } from './components/Sidebar';
import { IoTProvider } from './contexts/IoTContext';
import { AlertProvider } from './contexts/AlertContext';

function App() {
  const [activeView, setActiveView] = useState<'dashboard' | 'settings'>('dashboard');
  const [sidebarOpen, setSidebarOpen] = useState(false);

  return (
    <IoTProvider>
      <AlertProvider>
        <div className="min-h-screen bg-gradient-to-br from-slate-50 to-blue-50">
          <Header 
            onMenuClick={() => setSidebarOpen(true)}
            activeView={activeView}
            setActiveView={setActiveView}
          />
          
          <Sidebar 
            isOpen={sidebarOpen}
            onClose={() => setSidebarOpen(false)}
            activeView={activeView}
            setActiveView={setActiveView}
          />
          
          <main className="lg:ml-64 pt-16">
            <div className="p-4 lg:p-8">
              {activeView === 'dashboard' ? <Dashboard /> : <Settings />}
            </div>
          </main>
        </div>
      </AlertProvider>
    </IoTProvider>
  );
}

export default App;