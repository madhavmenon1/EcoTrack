import React from 'react';

interface LineChartProps {
  data: Array<{ time: string; value: number }>;
  color: string;
  label: string;
}

export function LineChart({ data, color, label }: LineChartProps) {
  const maxValue = Math.max(...data.map(d => d.value));
  const minValue = Math.min(...data.map(d => d.value));
  const range = maxValue - minValue || 1;

  const getY = (value: number) => {
    return ((maxValue - value) / range) * 200;
  };

  const points = data.map((point, index) => ({
    x: (index / (data.length - 1)) * 400,
    y: getY(point.value)
  }));

  const pathData = points.reduce((path, point, index) => {
    return path + (index === 0 ? `M ${point.x},${point.y}` : ` L ${point.x},${point.y}`);
  }, '');

  return (
    <div className="w-full h-64 relative">
      <svg viewBox="0 0 400 200" className="w-full h-full">
        <defs>
          <linearGradient id={`gradient-${color}`} x1="0%" y1="0%" x2="0%" y2="100%">
            <stop offset="0%" style={{ stopColor: color, stopOpacity: 0.3 }} />
            <stop offset="100%" style={{ stopColor: color, stopOpacity: 0 }} />
          </linearGradient>
        </defs>
        
        {/* Grid lines */}
        {[0, 1, 2, 3, 4].map(i => (
          <line
            key={i}
            x1="0"
            y1={i * 40}
            x2="400"
            y2={i * 40}
            stroke="#f1f5f9"
            strokeWidth="1"
          />
        ))}
        
        {/* Area fill */}
        <path
          d={`${pathData} L 400,200 L 0,200 Z`}
          fill={`url(#gradient-${color})`}
        />
        
        {/* Line */}
        <path
          d={pathData}
          fill="none"
          stroke={color}
          strokeWidth="2"
          className="animate-pulse"
        />
        
        {/* Data points */}
        {points.map((point, index) => (
          <circle
            key={index}
            cx={point.x}
            cy={point.y}
            r="3"
            fill={color}
            className="animate-pulse"
          />
        ))}
      </svg>
      
      <div className="absolute bottom-2 left-2 text-xs text-gray-500">
        {label}
      </div>
    </div>
  );
}