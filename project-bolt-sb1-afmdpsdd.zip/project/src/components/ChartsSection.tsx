import React from 'react';
import { LineChart } from './LineChart';
import { useIoT } from '../contexts/IoTContext';

export function ChartsSection() {
  const { data } = useIoT();

  return (
    <div className="space-y-6">
      <div className="bg-white/70 backdrop-blur-sm rounded-2xl p-6 border border-gray-200/50">
        <h2 className="text-lg font-semibold text-gray-900 mb-4">Water Usage Trends</h2>
        <LineChart
          data={data.water.history}
          color="#3B82F6"
          label="Water (L/min)"
        />
      </div>
      
      <div className="bg-white/70 backdrop-blur-sm rounded-2xl p-6 border border-gray-200/50">
        <h2 className="text-lg font-semibold text-gray-900 mb-4">Energy Consumption</h2>
        <LineChart
          data={data.energy.history}
          color="#F59E0B"
          label="Energy (kW)"
        />
      </div>
    </div>
  );
}