import React from 'react';
import { Droplets, Zap, Trash2, TrendingUp, TrendingDown } from 'lucide-react';
import { useIoT } from '../contexts/IoTContext';

export function MetricsGrid() {
  const { data } = useIoT();

  const metrics = [
    {
      title: 'Water Usage',
      value: `${data.water.current.toFixed(1)} L/min`,
      total: `${data.water.total.toFixed(0)} L today`,
      icon: Droplets,
      color: 'blue',
      trend: data.water.trend,
      change: '+12%'
    },
    {
      title: 'Energy Usage',
      value: `${data.energy.current.toFixed(1)} kW`,
      total: `${data.energy.total.toFixed(1)} kWh today`,
      icon: Zap,
      color: 'yellow',
      trend: data.energy.trend,
      change: '-8%'
    },
    {
      title: 'Waste Level',
      value: `${data.waste.level}%`,
      total: `${data.waste.daysUntilFull} days remaining`,
      icon: Trash2,
      color: 'green',
      trend: data.waste.trend,
      change: '+5%'
    }
  ];

  const getColorClasses = (color: string) => {
    switch (color) {
      case 'blue':
        return 'bg-blue-500 text-white';
      case 'yellow':
        return 'bg-yellow-500 text-white';
      case 'green':
        return 'bg-green-500 text-white';
      default:
        return 'bg-gray-500 text-white';
    }
  };

  return (
    <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
      {metrics.map((metric) => {
        const Icon = metric.icon;
        const TrendIcon = metric.trend === 'up' ? TrendingUp : TrendingDown;
        const trendColor = metric.trend === 'up' ? 'text-red-500' : 'text-green-500';
        
        return (
          <div
            key={metric.title}
            className="bg-white/70 backdrop-blur-sm rounded-2xl p-6 border border-gray-200/50 hover:shadow-lg transition-all duration-300"
          >
            <div className="flex items-center justify-between mb-4">
              <div className={`p-3 rounded-xl ${getColorClasses(metric.color)}`}>
                <Icon className="h-6 w-6" />
              </div>
              <div className={`flex items-center space-x-1 ${trendColor}`}>
                <TrendIcon className="h-4 w-4" />
                <span className="text-sm font-medium">{metric.change}</span>
              </div>
            </div>
            
            <div className="space-y-2">
              <h3 className="text-sm font-medium text-gray-600">{metric.title}</h3>
              <div className="space-y-1">
                <p className="text-2xl font-bold text-gray-900">{metric.value}</p>
                <p className="text-sm text-gray-500">{metric.total}</p>
              </div>
            </div>
          </div>
        );
      })}
    </div>
  );
}