import React from 'react';
import { Wifi, WifiOff, Battery, Signal } from 'lucide-react';
import { useIoT } from '../contexts/IoTContext';

export function DeviceStatus() {
  const { devices } = useIoT();

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'online':
        return 'text-green-500';
      case 'offline':
        return 'text-red-500';
      case 'warning':
        return 'text-yellow-500';
      default:
        return 'text-gray-500';
    }
  };

  const getStatusIcon = (status: string) => {
    switch (status) {
      case 'online':
        return <Wifi className="h-4 w-4" />;
      case 'offline':
        return <WifiOff className="h-4 w-4" />;
      default:
        return <Signal className="h-4 w-4" />;
    }
  };

  return (
    <div className="bg-white/70 backdrop-blur-sm rounded-2xl p-6 border border-gray-200/50">
      <h2 className="text-lg font-semibold text-gray-900 mb-4">Device Status</h2>
      
      <div className="space-y-4">
        {devices.map((device) => (
          <div
            key={device.id}
            className="flex items-center justify-between p-4 bg-gray-50/50 rounded-lg hover:bg-gray-50 transition-colors"
          >
            <div className="flex items-center space-x-3">
              <div className={`p-2 rounded-lg ${device.status === 'online' ? 'bg-green-100' : 'bg-red-100'}`}>
                {getStatusIcon(device.status)}
              </div>
              <div>
                <h3 className="font-medium text-gray-900">{device.name}</h3>
                <p className="text-sm text-gray-500">{device.type}</p>
              </div>
            </div>
            
            <div className="flex items-center space-x-2">
              <div className="flex items-center space-x-1">
                <Battery className="h-4 w-4 text-gray-400" />
                <span className="text-sm text-gray-600">{device.battery}%</span>
              </div>
              <div className={`w-2 h-2 rounded-full ${
                device.status === 'online' ? 'bg-green-500 animate-pulse' : 'bg-red-500'
              }`} />
            </div>
          </div>
        ))}
      </div>
      
      <div className="mt-4 pt-4 border-t border-gray-200/50">
        <div className="flex items-center justify-between text-sm">
          <span className="text-gray-600">Total Devices</span>
          <span className="font-medium">{devices.length}</span>
        </div>
        <div className="flex items-center justify-between text-sm mt-2">
          <span className="text-gray-600">Online</span>
          <span className="font-medium text-green-600">
            {devices.filter(d => d.status === 'online').length}
          </span>
        </div>
      </div>
    </div>
  );
}