import React from 'react';
import { X, Home, Settings as SettingsIcon, AlertTriangle, BarChart3 } from 'lucide-react';

interface SidebarProps {
  isOpen: boolean;
  onClose: () => void;
  activeView: 'dashboard' | 'settings';
  setActiveView: (view: 'dashboard' | 'settings') => void;
}

export function Sidebar({ isOpen, onClose, activeView, setActiveView }: SidebarProps) {
  const menuItems = [
    { id: 'dashboard', label: 'Dashboard', icon: Home },
    { id: 'settings', label: 'Settings', icon: SettingsIcon },
  ];

  return (
    <>
      {/* Overlay */}
      {isOpen && (
        <div 
          className="fixed inset-0 bg-black/50 z-40 lg:hidden"
          onClick={onClose}
        />
      )}
      
      {/* Sidebar */}
      <aside className={`fixed left-0 top-0 h-full w-64 bg-white/90 backdrop-blur-md border-r border-gray-200/50 z-50 transform transition-transform duration-300 ${
        isOpen ? 'translate-x-0' : '-translate-x-full'
      } lg:translate-x-0`}>
        <div className="p-4 border-b border-gray-200/50">
          <div className="flex items-center justify-between">
            <h2 className="text-lg font-semibold text-gray-900">Navigation</h2>
            <button
              onClick={onClose}
              className="lg:hidden p-2 rounded-lg hover:bg-gray-100 transition-colors"
              aria-label="Close menu"
            >
              <X className="h-5 w-5" />
            </button>
          </div>
        </div>
        
        <nav className="p-4 space-y-2">
          {menuItems.map((item) => {
            const Icon = item.icon;
            return (
              <button
                key={item.id}
                onClick={() => {
                  setActiveView(item.id as 'dashboard' | 'settings');
                  onClose();
                }}
                className={`w-full flex items-center space-x-3 px-4 py-3 rounded-lg font-medium transition-all ${
                  activeView === item.id
                    ? 'bg-blue-100 text-blue-700'
                    : 'text-gray-600 hover:text-gray-900 hover:bg-gray-100'
                }`}
              >
                <Icon className="h-5 w-5" />
                <span>{item.label}</span>
              </button>
            );
          })}
        </nav>
        
        <div className="absolute bottom-4 left-4 right-4">
          <div className="p-4 bg-gradient-to-r from-blue-500 to-purple-600 rounded-lg text-white">
            <div className="flex items-center space-x-2 mb-2">
              <AlertTriangle className="h-5 w-5" />
              <span className="font-medium">AI Status</span>
            </div>
            <p className="text-sm opacity-90">Anomaly detection active</p>
            <div className="mt-2 w-full bg-white/20 rounded-full h-2">
              <div className="bg-white h-2 rounded-full w-3/4 animate-pulse" />
            </div>
          </div>
        </div>
      </aside>
    </>
  );
}