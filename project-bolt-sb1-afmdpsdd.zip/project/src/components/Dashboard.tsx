import React from 'react';
import { MetricsGrid } from './MetricsGrid';
import { AlertsPanel } from './AlertsPanel';
import { ChartsSection } from './ChartsSection';
import { DeviceStatus } from './DeviceStatus';
import { useIoT } from '../contexts/IoTContext';

export function Dashboard() {
  const { isLoading, error } = useIoT();

  if (error) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="text-center">
          <div className="text-red-500 text-xl mb-2">⚠️</div>
          <h3 className="text-lg font-medium text-gray-900 mb-1">Connection Error</h3>
          <p className="text-gray-600">Unable to connect to IoT devices</p>
        </div>
      </div>
    );
  }

  if (isLoading) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="text-center">
          <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-600 mx-auto mb-4"></div>
          <p className="text-gray-600">Loading dashboard...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-gray-900">Dashboard</h1>
          <p className="text-gray-600">Monitor your home's water, energy, and waste systems</p>
        </div>
        <div className="flex items-center space-x-2">
          <div className="flex items-center space-x-2 text-sm text-gray-600">
            <div className="w-2 h-2 bg-green-500 rounded-full animate-pulse"></div>
            <span>Live</span>
          </div>
        </div>
      </div>

      <MetricsGrid />
      <AlertsPanel />
      
      <div className="grid grid-cols-1 xl:grid-cols-3 gap-6">
        <div className="xl:col-span-2">
          <ChartsSection />
        </div>
        <div>
          <DeviceStatus />
        </div>
      </div>
    </div>
  );
}