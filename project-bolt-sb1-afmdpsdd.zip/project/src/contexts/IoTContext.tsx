import React, { createContext, useContext, useEffect, useState } from 'react';

interface IoTData {
  water: {
    current: number;
    total: number;
    trend: 'up' | 'down';
    history: Array<{ time: string; value: number }>;
  };
  energy: {
    current: number;
    total: number;
    trend: 'up' | 'down';
    history: Array<{ time: string; value: number }>;
  };
  waste: {
    level: number;
    daysUntilFull: number;
    trend: 'up' | 'down';
  };
}

interface Device {
  id: string;
  name: string;
  type: string;
  status: 'online' | 'offline' | 'warning';
  battery: number;
}

interface IoTContextType {
  data: IoTData;
  devices: Device[];
  isLoading: boolean;
  error: string | null;
}

const IoTContext = createContext<IoTContextType | undefined>(undefined);

export function IoTProvider({ children }: { children: React.ReactNode }) {
  const [data, setData] = useState<IoTData>({
    water: {
      current: 12.5,
      total: 245,
      trend: 'up',
      history: generateHistory(12.5, 24)
    },
    energy: {
      current: 3.2,
      total: 18.4,
      trend: 'down',
      history: generateHistory(3.2, 24)
    },
    waste: {
      level: 68,
      daysUntilFull: 3,
      trend: 'up'
    }
  });

  const [devices] = useState<Device[]>([
    { id: '1', name: 'Water Flow Sensor', type: 'Water Monitor', status: 'online', battery: 87 },
    { id: '2', name: 'Smart Energy Meter', type: 'Energy Monitor', status: 'online', battery: 92 },
    { id: '3', name: 'Waste Bin Sensor', type: 'Waste Monitor', status: 'online', battery: 74 },
    { id: '4', name: 'Main Hub', type: 'Gateway', status: 'online', battery: 100 }
  ]);

  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    // Simulate initial loading
    const timer = setTimeout(() => {
      setIsLoading(false);
    }, 2000);

    return () => clearTimeout(timer);
  }, []);

  useEffect(() => {
    // Simulate real-time data updates
    const interval = setInterval(() => {
      setData(prevData => ({
        ...prevData,
        water: {
          ...prevData.water,
          current: Math.max(0, prevData.water.current + (Math.random() - 0.5) * 2),
          total: prevData.water.total + Math.random() * 0.5,
          history: [...prevData.water.history.slice(1), {
            time: new Date().toLocaleTimeString(),
            value: Math.max(0, prevData.water.current + (Math.random() - 0.5) * 2)
          }]
        },
        energy: {
          ...prevData.energy,
          current: Math.max(0, prevData.energy.current + (Math.random() - 0.5) * 1),
          total: prevData.energy.total + Math.random() * 0.2,
          history: [...prevData.energy.history.slice(1), {
            time: new Date().toLocaleTimeString(),
            value: Math.max(0, prevData.energy.current + (Math.random() - 0.5) * 1)
          }]
        },
        waste: {
          ...prevData.waste,
          level: Math.min(100, prevData.waste.level + Math.random() * 0.1)
        }
      }));
    }, 5000);

    return () => clearInterval(interval);
  }, []);

  return (
    <IoTContext.Provider value={{ data, devices, isLoading, error }}>
      {children}
    </IoTContext.Provider>
  );
}

export function useIoT() {
  const context = useContext(IoTContext);
  if (!context) {
    throw new Error('useIoT must be used within an IoTProvider');
  }
  return context;
}

function generateHistory(currentValue: number, hours: number) {
  const history = [];
  for (let i = hours; i >= 0; i--) {
    const time = new Date(Date.now() - i * 60 * 60 * 1000);
    const value = currentValue + (Math.random() - 0.5) * currentValue * 0.5;
    history.push({
      time: time.toLocaleTimeString(),
      value: Math.max(0, value)
    });
  }
  return history;
}