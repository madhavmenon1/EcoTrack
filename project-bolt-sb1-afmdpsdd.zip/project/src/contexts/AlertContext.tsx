import React, { createContext, useContext, useEffect, useState } from 'react';

interface Alert {
  id: string;
  type: 'warning' | 'error' | 'success' | 'info';
  title: string;
  description: string;
  timestamp: string;
}

interface AlertContextType {
  alerts: Alert[];
  addAlert: (alert: Omit<Alert, 'id' | 'timestamp'>) => void;
  removeAlert: (id: string) => void;
}

const AlertContext = createContext<AlertContextType | undefined>(undefined);

export function AlertProvider({ children }: { children: React.ReactNode }) {
  const [alerts, setAlerts] = useState<Alert[]>([]);

  const addAlert = (alert: Omit<Alert, 'id' | 'timestamp'>) => {
    const newAlert: Alert = {
      ...alert,
      id: Date.now().toString(),
      timestamp: new Date().toLocaleString()
    };
    setAlerts(prev => [newAlert, ...prev]);
  };

  const removeAlert = (id: string) => {
    setAlerts(prev => prev.filter(alert => alert.id !== id));
  };

  useEffect(() => {
    // Simulate AI anomaly detection
    const interval = setInterval(() => {
      const scenarios = [
        {
          type: 'warning' as const,
          title: 'Unusual Water Usage Detected',
          description: 'Water consumption is 45% higher than normal for this time of day. Possible leak detected in bathroom area.'
        },
        {
          type: 'error' as const,
          title: 'Energy Spike Alert',
          description: 'Sudden energy consumption increase detected. Check HVAC system for potential issues.'
        },
        {
          type: 'warning' as const,
          title: 'Waste Bin Nearly Full',
          description: 'Kitchen waste bin is at 85% capacity. Consider emptying soon to avoid overflow.'
        },
        {
          type: 'success' as const,
          title: 'Efficiency Improvement',
          description: 'Energy usage has decreased by 15% compared to last week. Great job on conservation!'
        }
      ];

      if (Math.random() < 0.3 && alerts.length < 3) {
        const scenario = scenarios[Math.floor(Math.random() * scenarios.length)];
        addAlert(scenario);
      }
    }, 15000);

    return () => clearInterval(interval);
  }, [alerts.length]);

  return (
    <AlertContext.Provider value={{ alerts, addAlert, removeAlert }}>
      {children}
    </AlertContext.Provider>
  );
}

export function useAlert() {
  const context = useContext(AlertContext);
  if (!context) {
    throw new Error('useAlert must be used within an AlertProvider');
  }
  return context;
}