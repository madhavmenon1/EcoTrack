# EcoTrack IoT Dashboard

A beautiful, production-ready IoT dashboard for monitoring water, energy, and waste systems with AI-powered anomaly detection.

## Features

- **Real-time Monitoring**: Track water usage, energy consumption, and waste levels
- **AI Anomaly Detection**: Intelligent alerts for unusual patterns and potential issues
- **Responsive Design**: Works perfectly on desktop, tablet, and mobile devices
- **Modern UI**: Glass-morphism design with smooth animations and micro-interactions
- **Live Data Visualization**: Interactive charts showing usage trends over time
- **Device Management**: Monitor IoT device status, battery levels, and connectivity
- **Configurable Settings**: Customizable thresholds and alert preferences

## Tech Stack

- **Frontend**: React 18 + TypeScript
- **Styling**: Tailwind CSS
- **Icons**: Lucide React
- **Build Tool**: Vite
- **Deployment**: Netlify

## Getting Started

1. Install dependencies:
```bash
npm install
```

2. Start the development server:
```bash
npm run dev
```

3. Build for production:
```bash
npm run build
```

## Project Structure

```
src/
├── components/          # React components
│   ├── Dashboard.tsx    # Main dashboard view
│   ├── Settings.tsx     # Settings configuration
│   ├── Header.tsx       # Navigation header
│   ├── Sidebar.tsx      # Mobile sidebar
│   ├── MetricsGrid.tsx  # Key metrics display
│   ├── AlertsPanel.tsx  # AI alerts panel
│   ├── ChartsSection.tsx # Data visualization
│   ├── DeviceStatus.tsx # IoT device monitoring
│   └── LineChart.tsx    # Custom chart component
├── contexts/            # React contexts
│   ├── IoTContext.tsx   # IoT data management
│   └── AlertContext.tsx # Alert system
├── App.tsx             # Main application
└── main.tsx            # Application entry point
```

## Features Overview

### Dashboard
- Real-time metrics for water, energy, and waste
- Trend indicators and percentage changes
- Interactive data visualization charts
- AI-powered anomaly detection alerts
- Device status monitoring

### Settings
- Configurable alert thresholds
- Data retention preferences
- Auto-refresh intervals
- Toggle notifications on/off

### AI Integration
- Automatic anomaly detection
- Smart alerts for unusual patterns
- Predictive insights for maintenance
- Energy efficiency recommendations

## Deployment

The application is deployed on Netlify and can be accessed at:
https://ecotrackdem.netlify.app

## License

MIT License - feel free to use this code for your own projects!